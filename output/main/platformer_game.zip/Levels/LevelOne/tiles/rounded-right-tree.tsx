<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="rounded-right-tree" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="../images/forest-tileset/rounded-right-tree.png" width="32" height="32"/>
</tileset>
