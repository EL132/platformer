<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Level One Tiles - EL" tilewidth="32" tileheight="32" tilecount="200" columns="10">
 <grid orientation="orthogonal" width="5" height="32"/>
 <image source="../images/small-edit.png" width="320" height="641"/>
</tileset>
