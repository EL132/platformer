<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="2" tilewidth="32" tileheight="32" tilecount="21" columns="3">
 <image source="../Objects/Trees/2.png" width="123" height="234"/>
</tileset>
