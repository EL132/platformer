<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Map2_tiles" tilewidth="32" tileheight="32" tilecount="156" columns="12">
 <image source="setTwo/1 Tiles/Map_tiles.png" width="384" height="416"/>
</tileset>
