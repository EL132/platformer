<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="6" tilewidth="59" tileheight="14" tilecount="1" columns="1">
 <image source="../Objects/Stones/6.png" width="59" height="14"/>
</tileset>
