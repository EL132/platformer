<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Alpha" tilewidth="32" tileheight="32" tilecount="60" columns="10">
 <image source="../Tileset.png" width="320" height="192"/>
</tileset>
