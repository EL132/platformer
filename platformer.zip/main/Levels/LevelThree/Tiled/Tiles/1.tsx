<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="1" tilewidth="32" tileheight="32" tilecount="6" columns="3">
 <image source="../Objects/Igloo/1.png" width="96" height="64"/>
</tileset>
