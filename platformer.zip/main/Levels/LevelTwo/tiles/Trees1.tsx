<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Trees1" tilewidth="32" tileheight="32" tilecount="44" columns="11">
 <image source="../images/tileset/trees.png" width="382" height="134"/>
</tileset>
