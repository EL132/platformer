#Set display surface (tile size is 32x32 ; 25 tiles wide, 14 tiles high)
WINDOW_WIDTH = 775
WINDOW_HEIGHT = 448

#Set FPS and clock
FPS = 60

# text font colors
BEIGE = (246,230,215)
GREY = (176,160,145)
DARK_GREY = (77,68,59)
RED = (241,90,74)