<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="shadows" tilewidth="40" tileheight="40" tilecount="24" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="6" height="5" source="setTwo/5 Shadows/e1.png"/>
 </tile>
 <tile id="1">
  <image width="8" height="5" source="setTwo/5 Shadows/e2.png"/>
 </tile>
 <tile id="2">
  <image width="10" height="7" source="setTwo/5 Shadows/e3.png"/>
 </tile>
 <tile id="3">
  <image width="16" height="11" source="setTwo/5 Shadows/e4.png"/>
 </tile>
 <tile id="4">
  <image width="20" height="15" source="setTwo/5 Shadows/e5.png"/>
 </tile>
 <tile id="5">
  <image width="26" height="19" source="setTwo/5 Shadows/e6.png"/>
 </tile>
 <tile id="6">
  <image width="32" height="23" source="setTwo/5 Shadows/e7.png"/>
 </tile>
 <tile id="7">
  <image width="40" height="29" source="setTwo/5 Shadows/e8.png"/>
 </tile>
 <tile id="8">
  <image width="6" height="6" source="setTwo/5 Shadows/r1.png"/>
 </tile>
 <tile id="9">
  <image width="8" height="8" source="setTwo/5 Shadows/r2.png"/>
 </tile>
 <tile id="10">
  <image width="10" height="10" source="setTwo/5 Shadows/r3.png"/>
 </tile>
 <tile id="11">
  <image width="16" height="16" source="setTwo/5 Shadows/r4.png"/>
 </tile>
 <tile id="12">
  <image width="20" height="20" source="setTwo/5 Shadows/r5.png"/>
 </tile>
 <tile id="13">
  <image width="26" height="26" source="setTwo/5 Shadows/r6.png"/>
 </tile>
 <tile id="14">
  <image width="32" height="32" source="setTwo/5 Shadows/r7.png"/>
 </tile>
 <tile id="15">
  <image width="40" height="40" source="setTwo/5 Shadows/r8.png"/>
 </tile>
 <tile id="16">
  <image width="6" height="6" source="setTwo/5 Shadows/s1.png"/>
 </tile>
 <tile id="17">
  <image width="8" height="8" source="setTwo/5 Shadows/s2.png"/>
 </tile>
 <tile id="18">
  <image width="10" height="10" source="setTwo/5 Shadows/s3.png"/>
 </tile>
 <tile id="19">
  <image width="16" height="16" source="setTwo/5 Shadows/s4.png"/>
 </tile>
 <tile id="20">
  <image width="20" height="20" source="setTwo/5 Shadows/s5.png"/>
 </tile>
 <tile id="21">
  <image width="26" height="26" source="setTwo/5 Shadows/s6.png"/>
 </tile>
 <tile id="22">
  <image width="32" height="32" source="setTwo/5 Shadows/s7.png"/>
 </tile>
 <tile id="23">
  <image width="40" height="40" source="setTwo/5 Shadows/s8.png"/>
 </tile>
</tileset>
