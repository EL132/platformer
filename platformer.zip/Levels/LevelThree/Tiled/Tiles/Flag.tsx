<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Flag" tilewidth="128" tileheight="48" tilecount="1" columns="1">
 <image source="../Objects/Flag.png" width="128" height="48"/>
</tileset>
