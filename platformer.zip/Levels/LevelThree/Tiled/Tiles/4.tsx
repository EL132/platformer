<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="4" tilewidth="92" tileheight="113" tilecount="1" columns="1">
 <image source="../Objects/Trees/4.png" width="92" height="113"/>
</tileset>
