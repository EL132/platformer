<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="middle-layer-2" tilewidth="32" tileheight="32" tilecount="15" columns="15">
 <image source="../Individual Edited Squares/middle-layer-2.png" width="480" height="32"/>
</tileset>
