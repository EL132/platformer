<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="5" tilewidth="127" tileheight="242" tilecount="1" columns="1">
 <image source="../Objects/Trees/1.png" width="127" height="242"/>
</tileset>
