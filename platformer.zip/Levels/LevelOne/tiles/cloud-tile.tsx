<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="cloud-tile" tilewidth="159" tileheight="63" tilecount="1" columns="1">
 <image source="../images/cloud.png" width="159" height="63"/>
</tileset>
