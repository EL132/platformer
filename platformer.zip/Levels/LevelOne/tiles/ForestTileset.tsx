<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="ForestTileset" tilewidth="32" tileheight="32" tilecount="63" columns="9">
 <image source="../images/forest-tileset/Tileset.png" width="288" height="224"/>
</tileset>
