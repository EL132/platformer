<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Tiles" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="../Tiles.png" width="256" height="256"/>
</tileset>
