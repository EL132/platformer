<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="UI" tilewidth="70" tileheight="38" tilecount="9" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="38" height="38" source="setOne/3 UI/circle1.png"/>
 </tile>
 <tile id="1">
  <image width="38" height="38" source="setOne/3 UI/circle2.png"/>
 </tile>
 <tile id="2">
  <image width="38" height="38" source="setOne/3 UI/circle3.png"/>
 </tile>
 <tile id="3">
  <image width="38" height="38" source="setOne/3 UI/circle4.png"/>
 </tile>
 <tile id="4">
  <image width="38" height="38" source="setOne/3 UI/circle5.png"/>
 </tile>
 <tile id="5">
  <image width="8" height="8" source="setOne/3 UI/Dot.png"/>
 </tile>
 <tile id="6">
  <image width="24" height="25" source="setOne/3 UI/Star1.png"/>
 </tile>
 <tile id="7">
  <image width="24" height="25" source="setOne/3 UI/Star2.png"/>
 </tile>
 <tile id="8">
  <image width="70" height="33" source="setOne/3 UI/Stars.png"/>
 </tile>
</tileset>
