<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="rocks" tilewidth="68" tileheight="40" tilecount="12" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="34" height="37" source="setTwo/2 Objects/Rocks/1.png"/>
 </tile>
 <tile id="1">
  <image width="44" height="33" source="setTwo/2 Objects/Rocks/2.png"/>
 </tile>
 <tile id="2">
  <image width="41" height="27" source="setTwo/2 Objects/Rocks/3.png"/>
 </tile>
 <tile id="3">
  <image width="51" height="38" source="setTwo/2 Objects/Rocks/4.png"/>
 </tile>
 <tile id="4">
  <image width="38" height="23" source="setTwo/2 Objects/Rocks/5.png"/>
 </tile>
 <tile id="5">
  <image width="38" height="31" source="setTwo/2 Objects/Rocks/6.png"/>
 </tile>
 <tile id="6">
  <image width="40" height="25" source="setTwo/2 Objects/Rocks/7.png"/>
 </tile>
 <tile id="7">
  <image width="23" height="12" source="setTwo/2 Objects/Rocks/8.png"/>
 </tile>
 <tile id="8">
  <image width="10" height="8" source="setTwo/2 Objects/Rocks/9.png"/>
 </tile>
 <tile id="9">
  <image width="56" height="26" source="setTwo/2 Objects/Rocks/10.png"/>
 </tile>
 <tile id="10">
  <image width="60" height="28" source="setTwo/2 Objects/Rocks/11.png"/>
 </tile>
 <tile id="11">
  <image width="68" height="40" source="setTwo/2 Objects/Rocks/12.png"/>
 </tile>
</tileset>
