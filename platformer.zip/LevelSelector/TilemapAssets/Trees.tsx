<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Trees" tilewidth="39" tileheight="48" tilecount="24" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="27" height="44" source="setOne/2 Objects/Trees/1.png"/>
 </tile>
 <tile id="1">
  <image width="23" height="38" source="setOne/2 Objects/Trees/2.png"/>
 </tile>
 <tile id="2">
  <image width="28" height="32" source="setOne/2 Objects/Trees/3.png"/>
 </tile>
 <tile id="3">
  <image width="27" height="39" source="setOne/2 Objects/Trees/4.png"/>
 </tile>
 <tile id="4">
  <image width="26" height="38" source="setOne/2 Objects/Trees/5.png"/>
 </tile>
 <tile id="5">
  <image width="15" height="22" source="setOne/2 Objects/Trees/6.png"/>
 </tile>
 <tile id="6">
  <image width="10" height="28" source="setOne/2 Objects/Trees/7.png"/>
 </tile>
 <tile id="7">
  <image width="11" height="37" source="setOne/2 Objects/Trees/8.png"/>
 </tile>
 <tile id="8">
  <image width="10" height="43" source="setOne/2 Objects/Trees/9.png"/>
 </tile>
 <tile id="9">
  <image width="39" height="43" source="setTwo/2 Objects/Trees/1.png"/>
 </tile>
 <tile id="10">
  <image width="31" height="37" source="setTwo/2 Objects/Trees/2.png"/>
 </tile>
 <tile id="11">
  <image width="29" height="41" source="setTwo/2 Objects/Trees/3.png"/>
 </tile>
 <tile id="12">
  <image width="24" height="16" source="setTwo/2 Objects/Trees/4.png"/>
 </tile>
 <tile id="13">
  <image width="19" height="14" source="setTwo/2 Objects/Trees/5.png"/>
 </tile>
 <tile id="14">
  <image width="14" height="9" source="setTwo/2 Objects/Trees/6.png"/>
 </tile>
 <tile id="15">
  <image width="16" height="27" source="setTwo/2 Objects/Trees/7.png"/>
 </tile>
 <tile id="16">
  <image width="17" height="23" source="setTwo/2 Objects/Trees/8.png"/>
 </tile>
 <tile id="17">
  <image width="11" height="17" source="setTwo/2 Objects/Trees/9.png"/>
 </tile>
 <tile id="18">
  <image width="39" height="37" source="setTwo/2 Objects/Trees/10.png"/>
 </tile>
 <tile id="19">
  <image width="27" height="37" source="setTwo/2 Objects/Trees/11.png"/>
 </tile>
 <tile id="20">
  <image width="31" height="45" source="setTwo/2 Objects/Trees/12.png"/>
 </tile>
 <tile id="21">
  <image width="29" height="48" source="setTwo/2 Objects/Trees/13.png"/>
 </tile>
 <tile id="22">
  <image width="19" height="35" source="setTwo/2 Objects/Trees/14.png"/>
 </tile>
 <tile id="23">
  <image width="13" height="25" source="setTwo/2 Objects/Trees/15.png"/>
 </tile>
</tileset>
