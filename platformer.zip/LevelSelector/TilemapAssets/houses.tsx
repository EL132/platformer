<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="houses" tilewidth="64" tileheight="90" tilecount="17" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="38" source="setOne/2 Objects/Houses/1.png"/>
 </tile>
 <tile id="1">
  <image width="33" height="38" source="setOne/2 Objects/Houses/2.png"/>
 </tile>
 <tile id="2">
  <image width="43" height="38" source="setOne/2 Objects/Houses/3.png"/>
 </tile>
 <tile id="3">
  <image width="35" height="63" source="setOne/2 Objects/Houses/4.png"/>
 </tile>
 <tile id="4">
  <image width="43" height="40" source="setOne/2 Objects/Houses/5.png"/>
 </tile>
 <tile id="5">
  <image width="27" height="26" source="setOne/2 Objects/Houses/6.png"/>
 </tile>
 <tile id="6">
  <image width="32" height="32" source="setTwo/2 Objects/Houses/1.png"/>
 </tile>
 <tile id="7">
  <image width="35" height="27" source="setTwo/2 Objects/Houses/2.png"/>
 </tile>
 <tile id="8">
  <image width="32" height="27" source="setTwo/2 Objects/Houses/3.png"/>
 </tile>
 <tile id="9">
  <image width="38" height="32" source="setTwo/2 Objects/Houses/4.png"/>
 </tile>
 <tile id="10">
  <image width="38" height="32" source="setTwo/2 Objects/Houses/5.png"/>
 </tile>
 <tile id="11">
  <image width="44" height="42" source="setTwo/2 Objects/Houses/6.png"/>
 </tile>
 <tile id="12">
  <image width="46" height="60" source="setTwo/2 Objects/Houses/7.png"/>
 </tile>
 <tile id="13">
  <image width="46" height="88" source="setTwo/2 Objects/Houses/8.png"/>
 </tile>
 <tile id="14">
  <image width="46" height="90" source="setTwo/2 Objects/Houses/9.png"/>
 </tile>
 <tile id="15">
  <image width="45" height="37" source="setTwo/2 Objects/Other/Pyramid1.png"/>
 </tile>
 <tile id="16">
  <image width="64" height="52" source="setTwo/2 Objects/Other/Pyramid2.png"/>
 </tile>
</tileset>
